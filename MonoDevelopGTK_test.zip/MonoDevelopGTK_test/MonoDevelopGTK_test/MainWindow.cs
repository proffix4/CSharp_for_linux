﻿using System;
using System.Reflection.Emit;
using Atk;
using Gtk;

public partial class MainWindow : Gtk.Window
{
    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }

    protected void OnButton1Clicked(object sender, EventArgs e)
    {
        label1.Text = "111";
    }
protected void OnButton2Clicked(object sender, EventArgs e)
    {
        label2.Text = "222";
    }
}
